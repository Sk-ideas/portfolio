/**
 * Cloudflare Worker — Sasi Portfolio AI Chat (Groq / Llama 3.3)
 *
 * Deploy steps:
 *   1. npm install -g wrangler
 *   2. wrangler login
 *   3. cd cloudflare-worker
 *   4. wrangler secret put GROQ_API_KEY   ← paste your free key
 *   5. wrangler deploy
 *   6. Copy the printed URL into main.js as CHAT_API_URL
 *
 * Free Groq key: https://console.groq.com/keys
 */

const SYSTEM_PROMPT = `You are an AI assistant embedded in Sasi Kumar S's personal portfolio website. Answer questions about Sasi in a friendly, concise, and professional tone. Keep responses under 120 words unless more detail is explicitly requested. Use short paragraphs or simple bullet points for clarity.

ABOUT SASI KUMAR S:

Personal:
- Full Name: Sasi Kumar S
- Birthday: 15 May 2000  |  Age: 26
- Location: Nagercoil, Tamil Nadu, India
- Email: sasikumar150500@gmail.com
- Phone / WhatsApp: +91 6383201475

Professional Summary:
Backend-focused Laravel engineer with 3+ years of experience building secure, workflow-driven enterprise applications. Specialises in RBAC, encrypted document lifecycle management, RESTful APIs, cron-based automation, and MySQL optimisation.

Current Role:
- Backend Laravel Engineer at ISKCON Bangalore (December 2025 - Present)
  Governance and resolution workflow systems with encrypted doc lifecycle and RBAC.
  Automated tracking, recurring reminders, cron-based workflow processing.

Previous Experience:
- Full-Stack Developer at Ziga Infotech Ventures Pvt Ltd (April 2023 - June 2025)
  Enterprise CRM, LMS, Inventory apps using Laravel and CodeIgniter.
  REST APIs, Excel bulk-upload pipelines, dynamic PDF generation.
  Production deployment, WHM/cPanel hosting, MySQL query optimisation.
- Freelance Developer at Women's Christian College (August 2025 - November 2025)
  Academic management system: admissions, student records, fee tracking, dashboards.

Skills:
- Backend: PHP, Laravel, CodeIgniter, RESTful APIs, SOAP, MySQL, Query Optimisation
- Security: RBAC, Encrypted Content, Document Lifecycle, Workflow Automation
- DevOps: Cron Jobs, WHM, cPanel, Plesk, Shared Hosting
- Frontend: JavaScript, jQuery, AJAX, HTML5, CSS3, Bootstrap, Vite
- Tools: Git, GitHub, Third-Party API Integration, Payment Gateway Integration
- Domains: Governance, CRM, LMS, Inventory Management, Academic Systems

Key Projects:
1. Governing Body Commission - Governance workflow, encrypted docs, RBAC, cron reminders
2. Asset Management System - Asset tracking, maintenance scheduling, audit automation
3. LMS and Admission Management (Spark Learning) - Admission lifecycle, fees, payments, timetables
4. CRM and Hierarchical Authority - Ward/district governance, controlled authority access
5. Inventory and Migration Systems - CodeIgniter inventory lifecycle
6. PS Granites - REST APIs, Excel upload, PDF generation with 10+ images per record

Education:
- B.E. Computer Science and Engineering - Ponjesly College of Engineering, Nagercoil (2018-2022, CGPA: 7.77/10)
- Full Stack PHP Training - SCOPE INDIA (2022, 4 months)
- Android Inplant Training - UniqTechnology, Chennai (2019)

Social:
- LinkedIn: https://www.linkedin.com/in/sasi-kumar-43b259228
- Portfolio: https://sk-ideas.github.io/portfolio/
- Instagram: https://www.instagram.com/mr.soul_knight/

If asked something not covered above, say you don't have that detail and suggest contacting Sasi directly. Never fabricate information.`;

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function respond(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (request.method !== 'POST') return respond({ error: 'Method not allowed' }, 405);

    const apiKey = env.GROQ_API_KEY;
    if (!apiKey) return respond({ error: 'GROQ_API_KEY not set. Run: wrangler secret put GROQ_API_KEY' }, 500);

    let input;
    try { input = await request.json(); }
    catch { return respond({ error: 'Invalid JSON body' }, 400); }

    const userMessage = (input.message ?? '').trim();
    if (!userMessage) return respond({ error: 'Empty message' }, 400);

    const rawHistory = Array.isArray(input.history) ? input.history.slice(-10) : [];
    const messages = [{ role: 'system', content: SYSTEM_PROMPT }];
    for (const h of rawHistory) {
      if (h.content && (h.role === 'user' || h.role === 'assistant')) {
        messages.push({ role: h.role, content: String(h.content) });
      }
    }
    messages.push({ role: 'user', content: userMessage });

    const upstream = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model:       'llama-3.3-70b-versatile',
        messages,
        max_tokens:  400,
        temperature: 0.7,
      }),
    });

    const data = await upstream.json();
    const text = data?.choices?.[0]?.message?.content;

    if (!upstream.ok || !text) {
      const msg = data?.error?.message ?? 'AI service error. Please try again.';
      return respond({ error: msg }, 500);
    }

    return respond({ response: text });
  },
};
